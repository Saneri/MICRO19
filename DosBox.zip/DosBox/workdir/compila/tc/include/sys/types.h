/*	types.h

	Types for dealing with time.

        Copyright (c) Borland International 1987,1988,1990
	All Rights Reserved.
*/

#ifndef  _TIME_T
#define  _TIME_T
typedef long time_t;
#endif
