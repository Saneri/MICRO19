// ex1.cpp:   A First Glance
// from Chapter 6 of User's Guide
#include <iostream.h>

main()
{
   cout << "Frankly, my dear...\n";
   cout << "C++ is a better C.\n";
}
